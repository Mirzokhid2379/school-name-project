import Home from './pages/home'
import React from 'react';
import './App.css';

function App() {
  return (
   <Home />
  );
}

export default App;
